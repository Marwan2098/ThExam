
<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>
<?php $__env->startSection('title'); ?>
    <?php echo e(trans('main_trans.list_students')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
    <?php echo e(trans('main_trans.today_quizes')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- row -->
    <div class="row">
        <div class="col-md-12 mb-30">
            <div class="card card-statistics h-100">
                <div class="card-body">
                    <div class="col-xl-12 mb-30">
                        <div class="card card-statistics h-100">
                            <div class="card-body">
                                <?php if(session('student_score')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('student_score')); ?>

                                </div>
                                <?php endif; ?>
                                <div class="table-responsive">
                                    <table id="datatable" class="table  table-hover table-sm table-bordered p-0"
                                           data-page-length="50"
                                           style="text-align: center">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Quiz title</th>
                                                <th>Doctor</th>
                                                <th>Sections</th>
                                                <th>Year</th>
                                                <th>Department</th>
                                                <th><?php echo e(trans('main_trans.date_of_quiz')); ?></th>
                                                <th><?php echo e(trans('main_trans.quiz_duration')); ?></th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $quizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quizze): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($quizze->name); ?></td>
                                                <td><?php echo e($quizze->teacher->Name); ?></td>
                                                <td><?php echo e($quizze->grade->Name); ?></td>
                                                <td><?php echo e($quizze->classroom->Name_Class); ?></td>
                                                <td><?php echo e($quizze->section->Name_Section); ?></td>
                                                <td><?php echo e($quizze->date_of_quiz); ?></td>
                                                <td><?php echo e($quizze->quiz_duration); ?></td>
                                                <td>
                                                    <?php 
                                                $check_quiz_performed=App\Models\StudentQuiz::where('quizze_id',$quizze->id)
                                                ->where('student_id',auth()->guard('student')->user()->id)->first();
                                                    ?>
                                                    <?php if(! $check_quiz_performed): ?>
                                                    <a href="<?php echo e(url('/student/perform-exam/'.$quizze->id)); ?>"
                                                       class="btn btn-info btn-sm" role="button" aria-pressed="true"><i
                                                            class="fa fa-open"></i>Start Quiz</a>
                                                        <?php else: ?>
                                                        <a class="btn btn-danger text-white btn-sm" role="button" aria-pressed="true"><i
                                                                 class="fa fa-open"></i>Quiz Finished</a>
                                                        <?php endif; ?>
                                                </td>
                                            </tr>
                                     
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php echo toastr_js(); ?>
    <?php echo app('toastr')->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\TheExam 23-5\resources\views/pages/Students/today_quizzes.blade.php ENDPATH**/ ?>
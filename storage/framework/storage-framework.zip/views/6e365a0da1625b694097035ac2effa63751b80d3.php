<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>
<?php $__env->startSection('title'); ?>
Perform Exam
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
Perform Exam
<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<input class="red_url" value="<?php echo e(url('/student/today-quizzes')); ?>" type="hidden">
<input class="quiz_time" value="<?php echo e($end_time); ?>" type="hidden">


    <!-- row -->
    <div class="row">
        <div class="col-md-12 mb-30">
            <div class="card card-statistics h-100">
                <div class="card-body">

                    <?php if(session()->has('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong><?php echo e(session()->get('error')); ?></strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <div class="alert alert-info">
                        <strong>Timer: </strong>
                        <div id="timer" style="font-size: 20px"></div>
                    </div>

                    <div id="question-wrapper">

                    <div class="col-xs-12"  >
                        <div class="col-md-12">
                            <br>
                            <span style="color: red">Question Numbers:<?php echo e($quiz->questions->count()); ?></span>
                            <span style="color: red">Quiz Time:<?php echo e($quiz->quiz_duration); ?> hour(s)</span>
                            <form action="<?php echo e(url('/student/end-exam')); ?>" method="post" autocomplete="off" id="form-test">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="quiz_id" value="<?php echo e($quiz->id); ?>">
                                <?php $__currentLoopData = $quiz->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <input type="hidden" value="<?php echo e($question->id); ?>" name="question[]">
                                <div class="form-row">

                                    <div class="col">

                                        <label for="title">Question</label>
                                        <input type="text" readonly value="<?php echo e($question->title); ?>" id="input-name"
                                               class="form-control form-control-alternative" autofocus>
                                    </div>
                                </div>
                                <br>

                                <div class="form-row">
                                    <div class="col">
                                        <label for="title">Answer</label>
                                        <select name="right_answer[]"  class="form-control form-control select2" style="padding:3px">
                                            <?php $answers = explode(PHP_EOL, $question->answers); ?>
                                            <option value="">Please Select</option>
                                            <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($answer); ?>"><?php echo e($answer); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <button class="btn btn-success btn-sm nextBtn btn-lg pull-right" onclick="finish()" type="submit">End Exam</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection("js"); ?>
<script src="<?php echo e(asset('js/face/webgazer.js')); ?>" type="text/javascript"></script>

<script>
    $("#question-wrapper").hide();

    jQuery.fn.center = function () {
        this.css("position","absolute");
        this.css("top", "20px");
        this.css("left", Math.max(0, (($(window).width() - $(this).outerWidth()) / 2) +
            $(window).scrollLeft()) + "px");
        return this;
    }

    let isFinish = false;
    function finish() {
        isFinish = true;
        $("#form-test").submit();
    }
    $(function() {

        $(window).blur(function() {
            if(isFinish === false) {
                $.get("<?php echo e(url('/api/abort-test/{error}')); ?>");
                alert("Another Browser Tab Opened,Quiz Will Be Closed !");
                red_url=$('.red_url').val();
                location.href = red_url;
            }
        });
    })

    let timeout = null;
    let xPred = null;
    let yPred = null;
    let eyeCatch = false;
    let eyeLost = false;
    let preDiskual = false;

    var targetObj = {};
    var targetProxy = new Proxy(targetObj, {
        set: function (target, key, value) {
            if(key === 'eyeLost' && value === true) {
                faceNotDetected();
            }
            console.log(`${key} set to ${value}`);
            target[key] = value;
            return true;
        }
    });

    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    async function faceNotDetected()
    {
        webgazer.pause();
        isFinish = true;
        $("#question-wrapper").hide();
        // await alert("Wajah tidak terdeteksi!");
        await $.get("<?php echo e(url('/api/abort-test/{error}')); ?>");
        alert("Quiz Will Be Closed Because you leaved camera !");
                red_url=$('.red_url').val();
                location.href = red_url;
        await sleep(1500);
    }

    async function main() {
        await webgazer.setGazeListener(function(data, elapsedTime) {
            if (data == null) {
                return;
            }
            xPred = data.x; //these x coordinates are relative to the viewport
            yPred = data.y; //these y coordinates are relative to the viewport
            eyeCatch = true;
        }).begin();


        let check = setInterval(async ()=> {
            $("#webgazerVideoContainer").center();

            if(eyeCatch) {

                let inside = $("#webgazerFaceFeedbackBox").attr('style');
                if(inside && inside.includes("solid green") && xPred && yPred) {
                    console.log("Face inside");
                    $("#alert-waiting-webcam").hide();
                    $("#question-wrapper").show();
                    clearTimeout(timeout);
                    preDiskual = false;
                } else {
                    $("#question-wrapper").hide();
                    $("#alert-waiting-webcam").html("Please focus on the form, in 3 seconds the system will be locked...").show();
                    if(preDiskual === false) {
                        preDiskual = true;
                        timeout = setTimeout(function() {
                            targetProxy.eyeLost = true;
                            clearInterval(check);

                        }, 3000);
                    }
                }
            }
        }
        ,500);

        // let check2 = setInterval(async ()=>{
        //     $("#webgazerVideoContainer").center();
        // }, 100);
    }

    main();


    // Count down timer
    // Set the countdown end time
    // let countDownDate = new Date(new Date().setHours(new Date().getHours() + 1));
    // alert(countDownDate);
    let countDownDate=new Date($('.quiz_time').val()).getTime();
    // alert(countDownDate);
    // Update countdown every 1 second
    var x = setInterval(function() {

        // To get today's date and time
        // var now = $('.datenow').val();
        var now = new Date().getTime();

        // Find the distance between now and the countdown date
        var distance = countDownDate - now;

        // Calculation of time for days, hours, minutes and seconds
        // var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);

        // Output result in element with id="demo"
        document.getElementById("timer").innerHTML =hours + "h "
            + minutes + "m " + seconds + "s ";

        // When the countdown is over, write some text
        if (distance < 0) {
            $("#form-test").submit();
            clearInterval(x);
            // isFinish = true;
            // $.get("<?php echo e(url('/api/abort-test/{timeout}')); ?>");

            // alert("Time Out Quiz Will Be Closed !");
                // red_url=$('.red_url').val();
                // location.href = red_url;
            document.getElementById("timer").innerHTML = "EXPIRED";
        }
    }, 1000);

    function disableF5(e) { if ((e.which || e.keyCode) == 116 || (e.which || e.keyCode) == 82) e.preventDefault(); };

    $(document).ready(function(){
        $(document).on("keydown", disableF5);
    });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php echo toastr_js(); ?>
    <?php echo app('toastr')->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\TheExam 23-5last\resources\views/pages/Students/perform_exam.blade.php ENDPATH**/ ?>

<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>
<?php $__env->startSection('title'); ?>
    <?php echo e(trans('main_trans.previous_quizes')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
    <?php echo e(trans('main_trans.previous_quizes')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- row -->
    <div class="row">
        <div class="col-md-12 mb-30">
            <div class="card card-statistics h-100">
                <div class="card-body">
                    <div class="col-xl-12 mb-30">
                        <div class="card card-statistics h-100">
                            <div class="card-body">
                              
                                <div class="table-responsive">
                                    <table id="datatable" class="table  table-hover table-sm table-bordered p-0"
                                           data-page-length="50"
                                           style="text-align: center">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Quiz title</th>
                                                <th>Doctor</th>
                                                <th>Sections</th>
                                                <th>Year</th>
                                                <th>Department</th>
                                                <th><?php echo e(trans('main_trans.date_of_quiz')); ?></th>
                                                <th><?php echo e(trans('main_trans.quiz_duration')); ?></th>
                                                <th>Quiz Degree</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $quizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quizze): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($quizze->quiz->name); ?></td>
                                                <td><?php echo e($quizze->quiz->teacher->Name); ?></td>
                                                <td><?php echo e($quizze->quiz->grade->Name); ?></td>
                                                <td><?php echo e($quizze->quiz->classroom->Name_Class); ?></td>
                                                <td><?php echo e($quizze->quiz->section->Name_Section); ?></td>
                                                <td><?php echo e($quizze->quiz->date_of_quiz); ?></td>
                                                <td><?php echo e($quizze->quiz->quiz_duration); ?></td>
                                                <td><?php echo e($quizze->score); ?></td>
                                             
                                            </tr>
                                     
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php echo toastr_js(); ?>
    <?php echo app('toastr')->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TheExam 23-5last\TheExam 23-5last\resources\views/pages/Students/previous_quizes.blade.php ENDPATH**/ ?>
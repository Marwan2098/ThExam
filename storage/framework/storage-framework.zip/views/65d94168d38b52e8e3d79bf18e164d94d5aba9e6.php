<div class="modal fade" id="delete_exam<?php echo e($question->id); ?>" tabindex="-1"
     role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form action="<?php echo e(route('Questions.destroy','test')); ?>" method="post">
            <?php echo e(method_field('delete')); ?>

            <?php echo e(csrf_field()); ?>

            <div class="modal-content">
                <div class="modal-header">
                    <h5 style="font-family: 'Cairo', sans-serif;"
                        class="modal-title" id="exampleModalLabel">Delete Question</h5>
                    <button type="button" class="close" data-dismiss="modal"
                            aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p> <?php echo e(trans('My_Classes_trans.Warning_Grade')); ?> <?php echo e($question->name); ?></p>
                    <input type="hidden" name="id" value="<?php echo e($question->id); ?>">
                </div>
                <div class="modal-footer">
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary"
                                data-dismiss="modal"><?php echo e(trans('My_Classes_trans.Close')); ?></button>
                        <button type="submit" class="btn btn-danger"><?php echo e(trans('My_Classes_trans.submit')); ?></button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\TheExam 23-5last\TheExam 23-5last\resources\views/pages/Questions/destroy.blade.php ENDPATH**/ ?>